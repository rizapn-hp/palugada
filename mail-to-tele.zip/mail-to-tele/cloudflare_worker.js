/**
 * Cloudflare Email Worker (Zero External Dependencies)
 * Forwards incoming RFC822 raw email stream to your self-hosted gateway via Cloudflare Tunnel.
 *
 * Environment Variables required in Worker Settings:
 * - MINIPC_WEBHOOK_URL: e.g. https://mail-hook.yourdomain.com/api/incoming-raw
 * - WEBHOOK_SECRET: same secret configured in your gateway .env
 */

export default {
  async email(message, env, ctx) {
    try {
      const rawEmail = await new Response(message.raw).arrayBuffer();
      const webhookUrl = env.MINIPC_WEBHOOK_URL || 'https://mail-hook.yourdomain.com/api/incoming-raw';
      const secret = env.WEBHOOK_SECRET || '';

      const resp = await fetch(webhookUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'message/rfc822',
          'X-Webhook-Secret': secret,
          'X-Mail-From': message.from,
          'X-Mail-To': message.to
        },
        body: rawEmail
      });

      if (!resp.ok) {
        const errText = await resp.text();
        console.error(`Forward failed (${resp.status}): ${errText}`);
      } else {
        console.log(`Email from ${message.from} forwarded successfully.`);
      }
    } catch (err) {
      console.error('Email Worker exception:', err);
    }
  }
};
