import os
import re
import html
import logging
import email
from email import policy
from email.message import EmailMessage
from contextlib import asynccontextmanager
from typing import Optional

import aiosqlite
import aiosmtplib
import httpx
from fastapi import FastAPI, Header, HTTPException, Request
from pydantic import BaseModel, Field
from telegram import Update
from telegram.constants import ParseMode
from telegram.ext import (
    Application,
    ApplicationBuilder,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    filters,
)

logging.basicConfig(
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    level=logging.INFO
)
logger = logging.getLogger("mail-tg-gateway")

# Configuration from Environment Variables
DB_PATH = os.getenv("DB_PATH", "/app/data/emails.db")
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
TELEGRAM_CHAT_ID = int(os.getenv("TELEGRAM_CHAT_ID", "0").strip() or 0)
WEBHOOK_SECRET = os.getenv("WEBHOOK_SECRET", "").strip()
MAIL_FROM = os.getenv("MAIL_FROM", "hello@yourdomain.com").strip()
RESEND_API_KEY = os.getenv("RESEND_API_KEY", "").strip()
SMTP_HOST = os.getenv("SMTP_HOST", "").strip()
SMTP_PORT = int(os.getenv("SMTP_PORT", "587").strip() or 587)
SMTP_USER = os.getenv("SMTP_USER", "").strip()
SMTP_PASS = os.getenv("SMTP_PASS", "").strip()
SMTP_USE_TLS = os.getenv("SMTP_USE_TLS", "true").strip().lower() in ("true", "1", "yes")

bot_app: Optional[Application] = None


async def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS email_threads (
                tg_message_id INTEGER PRIMARY KEY,
                from_email TEXT NOT NULL,
                to_email TEXT NOT NULL,
                subject TEXT NOT NULL,
                message_id TEXT NOT NULL,
                date TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.commit()
    logger.info("Database initialized at %s", DB_PATH)


async def save_email_thread(tg_message_id: int, from_email: str, to_email: str, subject: str, message_id: str, date: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            INSERT OR REPLACE INTO email_threads (tg_message_id, from_email, to_email, subject, message_id, date)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (tg_message_id, from_email, to_email, subject, message_id, date))
        await db.commit()


async def get_email_thread(tg_message_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute("""
            SELECT from_email, to_email, subject, message_id, date
            FROM email_threads
            WHERE tg_message_id = ?
        """, (tg_message_id,))
        row = await cursor.fetchone()
        if row:
            return {
                "from_email": row[0],
                "to_email": row[1],
                "subject": row[2],
                "message_id": row[3],
                "date": row[4]
            }
        return None


async def send_outgoing_email(to_email: str, subject: str, body: str, in_reply_to: str):
    # Option A: Resend API
    if RESEND_API_KEY:
        headers = {
            "Authorization": f"Bearer {RESEND_API_KEY}",
            "Content-Type": "application/json"
        }
        payload = {
            "from": MAIL_FROM,
            "to": [to_email],
            "subject": subject,
            "text": body
        }
        if in_reply_to:
            payload["headers"] = {
                "In-Reply-To": in_reply_to,
                "References": in_reply_to
            }
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.post("https://api.resend.com/emails", json=payload, headers=headers)
            if resp.status_code >= 400:
                raise Exception(f"Resend API Error ({resp.status_code}): {resp.text}")
            return resp.json().get("id")

    # Option B: SMTP Relay (e.g. Brevo, SendGrid, Gmail)
    elif SMTP_HOST:
        msg = EmailMessage()
        msg["From"] = MAIL_FROM
        msg["To"] = to_email
        msg["Subject"] = subject
        if in_reply_to:
            msg["In-Reply-To"] = in_reply_to
            msg["References"] = in_reply_to
        msg.set_content(body)

        await aiosmtplib.send(
            msg,
            hostname=SMTP_HOST,
            port=SMTP_PORT,
            username=SMTP_USER or None,
            password=SMTP_PASS or None,
            start_tls=SMTP_USE_TLS
        )
        return "smtp-success"
    else:
        raise Exception("Outbound email configuration missing: set RESEND_API_KEY or SMTP_HOST in .env")


async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    await update.message.reply_text(
        f"🤖 <b>Mail-Telegram Gateway Active</b>\n\n"
        f"Your Telegram User ID: <code>{user_id}</code>\n\n"
        f"Add this ID to your <code>.env</code> file under <code>TELEGRAM_CHAT_ID</code>.",
        parse_mode=ParseMode.HTML
    )


async def cmd_ping(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("🏓 Pong! Gateway is healthy and running.")


async def handle_telegram_reply(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = update.effective_message
    if not msg or not msg.text:
        return

    # Restrict to configured owner ID
    if TELEGRAM_CHAT_ID and update.effective_user.id != TELEGRAM_CHAT_ID:
        logger.warning("Unauthorized access attempt from user: %s", update.effective_user.id)
        return

    if not msg.reply_to_message:
        return

    parent_id = msg.reply_to_message.message_id
    thread = await get_email_thread(parent_id)

    if not thread:
        await msg.reply_text("⚠️ Email metadata not found (not a reply to a recognized email notification).")
        return

    subj = thread["subject"]
    if not subj.lower().startswith("re:"):
        subj = f"Re: {subj}"

    raw_from = thread["from_email"]
    match = re.search(r'<([^>]+)>', raw_from)
    target_email = match.group(1) if match else raw_from.strip()

    await msg.reply_chat_action("typing")

    try:
        await send_outgoing_email(
            to_email=target_email,
            subject=subj,
            body=msg.text,
            in_reply_to=thread.get("message_id", "")
        )
        await msg.reply_text(
            f"✅ <b>Email Sent!</b>\n"
            f"👤 <b>To:</b> <code>{html.escape(target_email)}</code>\n"
            f"📝 <b>Subject:</b> {html.escape(subj)}",
            parse_mode=ParseMode.HTML
        )
        # Store reply so conversation threads continue
        await save_email_thread(
            tg_message_id=msg.message_id,
            from_email=target_email,
            to_email=MAIL_FROM,
            subject=subj,
            message_id=thread.get("message_id", ""),
            date=""
        )
    except Exception as e:
        logger.error("Failed to send email: %s", e, exc_info=True)
        await msg.reply_text(
            f"❌ <b>Failed to send email:</b>\n<code>{html.escape(str(e))}</code>",
            parse_mode=ParseMode.HTML
        )


@asynccontextmanager
async def lifespan(app: FastAPI):
    global bot_app
    await init_db()

    if not TELEGRAM_BOT_TOKEN:
        logger.warning("TELEGRAM_BOT_TOKEN is empty! Bot polling disabled.")
    else:
        bot_app = ApplicationBuilder().token(TELEGRAM_BOT_TOKEN).build()
        bot_app.add_handler(CommandHandler("start", cmd_start))
        bot_app.add_handler(CommandHandler("ping", cmd_ping))
        bot_app.add_handler(MessageHandler(filters.REPLY & filters.TEXT, handle_telegram_reply))

        await bot_app.initialize()
        await bot_app.start()
        await bot_app.updater.start_polling(drop_pending_updates=True)
        logger.info("Telegram Bot polling started successfully.")

    yield

    if bot_app:
        if bot_app.updater and bot_app.updater.running:
            await bot_app.updater.stop()
        await bot_app.stop()
        await bot_app.shutdown()
        logger.info("Telegram Bot stopped gracefully.")


app = FastAPI(title="Mail to Telegram Gateway", lifespan=lifespan)


class IncomingEmail(BaseModel):
    from_: str = Field(alias="from")
    to: str
    subject: Optional[str] = "(No Subject)"
    text: Optional[str] = ""
    messageId: Optional[str] = ""
    date: Optional[str] = ""


@app.get("/health")
async def health_check():
    return {"status": "ok", "bot_active": bot_app is not None}


async def dispatch_to_telegram(from_email: str, to_email: str, subject: str, message_id: str, date_str: str, body_text: str):
    subj = subject or "(No Subject)"
    body_snippet = (body_text or "(No text content)").strip()
    if len(body_snippet) > 3500:
        body_snippet = body_snippet[:3500] + "\n\n...[content truncated]..."

    from_escaped = html.escape(from_email)
    to_escaped = html.escape(to_email)
    subj_escaped = html.escape(subj)
    body_escaped = html.escape(body_snippet)

    msg_html = (
        f"📬 <b>Incoming Email</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"👤 <b>From:</b> <code>{from_escaped}</code>\n"
        f"🎯 <b>To:</b> <code>{to_escaped}</code>\n"
        f"📝 <b>Subject:</b> <b>{subj_escaped}</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━\n\n"
        f"{body_escaped}\n\n"
        f"💡 <i>Swipe / Reply to this message in Telegram to reply to the sender.</i>"
    )

    sent = await bot_app.bot.send_message(
        chat_id=TELEGRAM_CHAT_ID,
        text=msg_html,
        parse_mode=ParseMode.HTML
    )
    await save_email_thread(
        tg_message_id=sent.message_id,
        from_email=from_email,
        to_email=to_email,
        subject=subj,
        message_id=message_id or "",
        date=date_str or ""
    )
    return sent.message_id


@app.post("/api/incoming")
async def receive_incoming_json(
    payload: IncomingEmail,
    x_webhook_secret: Optional[str] = Header(None, alias="X-Webhook-Secret")
):
    if WEBHOOK_SECRET and x_webhook_secret != WEBHOOK_SECRET:
        raise HTTPException(status_code=403, detail="Invalid Webhook Secret")
    if not bot_app or not TELEGRAM_CHAT_ID:
        raise HTTPException(status_code=500, detail="Telegram Bot / Chat ID not ready")

    tg_id = await dispatch_to_telegram(
        from_email=payload.from_,
        to_email=payload.to,
        subject=payload.subject or "(No Subject)",
        message_id=payload.messageId or "",
        date_str=payload.date or "",
        body_text=payload.text or ""
    )
    return {"status": "ok", "tg_message_id": tg_id}


@app.post("/api/incoming-raw")
async def receive_incoming_raw(
    request: Request,
    x_webhook_secret: Optional[str] = Header(None, alias="X-Webhook-Secret"),
    x_mail_from: Optional[str] = Header(None, alias="X-Mail-From"),
    x_mail_to: Optional[str] = Header(None, alias="X-Mail-To")
):
    if WEBHOOK_SECRET and x_webhook_secret != WEBHOOK_SECRET:
        raise HTTPException(status_code=403, detail="Invalid Webhook Secret")
    if not bot_app or not TELEGRAM_CHAT_ID:
        raise HTTPException(status_code=500, detail="Telegram Bot / Chat ID not ready")

    raw_bytes = await request.body()
    try:
        parsed_msg = email.message_from_bytes(raw_bytes, policy=policy.default)
    except Exception as e:
        logger.error("Failed to parse raw RFC822 email: %s", e)
        raise HTTPException(status_code=400, detail=f"Failed to parse email: {e}")

    from_email = str(parsed_msg.get("From") or x_mail_from or "Unknown")
    to_email = str(parsed_msg.get("To") or x_mail_to or MAIL_FROM)
    subject = str(parsed_msg.get("Subject") or "(No Subject)")
    message_id = str(parsed_msg.get("Message-ID") or "")
    date_str = str(parsed_msg.get("Date") or "")

    body_text = ""
    try:
        body_part = parsed_msg.get_body(preferencelist=('plain', 'html'))
        if body_part:
            body_text = body_part.get_content()
    except Exception as e:
        logger.warning("Failed to extract body with preference list: %s", e)
        for part in parsed_msg.walk():
            if part.get_content_type() == "text/plain":
                payload = part.get_payload(decode=True)
                if payload:
                    body_text = payload.decode(errors="replace")
                    break

    tg_id = await dispatch_to_telegram(
        from_email=from_email,
        to_email=to_email,
        subject=subject,
        message_id=message_id,
        date_str=date_str,
        body_text=body_text
    )
    return {"status": "ok", "tg_message_id": tg_id}
